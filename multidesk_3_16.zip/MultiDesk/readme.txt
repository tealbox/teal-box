MultiDesk v3.16
2015-03-16

http://www.syvik.com/multidesk/

MultiDesk is a tabbed Remote Desktop Connection (Terminal Services Client).


Features:

* Only ONE executable file, small, fast (written in C++), green!
* Portable and SSD/flash drive friendly
* New style: status bar and fit window with margin
* Manage remote desktop connections in groups
* Inherit username and password from group properties
* Drag and drop support for moving servers and groups
* Tabbed connections
* Connect to console
* Change connection port
* Import cached MSTSC connections
* Redirect specified drives (Need RDP 6)
* Quick Connect
* Convenient Full Screen resolution switch


Requires:

Microsoft Remote Desktop Connection (Terminal Services Client) 6.0 or higher (optional)
Windows XP/2003 or higher


RDP 6 Download Links:

Remote Desktop Connection (Terminal Services Client 6.1) for Windows XP (KB952155)
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=6e1ec93d-bdbd-4983-92f7-479e088570ad

Remote Desktop Connection (Terminal Services Client 6.0) for Windows XP x64 Edition (KB925876)
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=160ce316-bf2b-48d0-a035-e2abbc55d8e8

Remote Desktop Connection (Terminal Services Client 6.0) for Windows Server 2003 (KB925876)
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=cc148041-577f-4201-b62c-d71adc98adb1

Remote Desktop Connection (Terminal Services Client 6.0) for Windows Server 2003 x64 Edition (KB925876)
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=43c0eae9-6b64-428f-a9dc-f97f5a1b4493
